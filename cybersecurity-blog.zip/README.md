# RONNY | Sistemas & Ciberseguridad

Blog personal técnico enfocado en ciberseguridad, pentesting y seguridad de sistemas con enfoque educativo y ético.

## 🚀 Características

- **Framework**: Next.js 14 con App Router
- **Styling**: TailwindCSS con tema dark/hacker
- **Contenido**: MDX con syntax highlighting (rehype-pretty-code)
- **SEO**: Metadata completa, sitemap, robots.txt, RSS
- **Búsqueda**: Cliente con Fuse.js
- **Comentarios**: Giscus (GitHub Discussions)
- **Newsletter**: Buttondown integration
- **Analytics**: Vercel Analytics

## 🎨 Diseño

- **Paleta**: Fondo #0B0F14, acentos verde #00FF7F y cian #5EEAD4
- **Tipografías**: Inter (UI) + JetBrains Mono (código)
- **Estilo**: Dark/hacker profesional y minimalista
- **Responsive**: Mobile-first design

## 📁 Estructura

\`\`\`
├── app/                    # App Router pages
│   ├── articles/          # Blog posts
│   ├── resources/         # Recursos de ciberseguridad
│   ├── projects/          # Portafolio de proyectos
│   ├── about/            # Sobre mí
│   └── contact/          # Contacto
├── components/           # Componentes reutilizables
├── content/posts/        # Posts en MDX
├── lib/                 # Utilidades y configuración
└── public/              # Assets estáticos
\`\`\`

## 🛠️ Desarrollo Local

\`\`\`bash
# Instalar dependencias
npm install

# Ejecutar en desarrollo
npm run dev

# Build para producción
npm run build

# Ejecutar build localmente
npm start
\`\`\`

## 📝 Crear Nuevo Post

1. Crear archivo MDX en `content/posts/`
2. Usar el siguiente frontmatter:

\`\`\`yaml
---
title: "Título del post"
description: "Descripción SEO"
date: "2024-01-01"
category: "Categoría"
tags: ["tag1", "tag2"]
readTime: "X min"
author: "Ronny"
---
\`\`\`

## 🔧 Configuración

### Variables de Entorno

\`\`\`env
BUTTONDOWN_API_KEY=tu_api_key_buttondown
NEXT_PUBLIC_GISCUS_REPO=usuario/repo
NEXT_PUBLIC_GISCUS_REPO_ID=repo_id
NEXT_PUBLIC_GISCUS_CATEGORY=General
NEXT_PUBLIC_GISCUS_CATEGORY_ID=category_id
\`\`\`

### Giscus Setup

1. Instalar Giscus app en tu repositorio
2. Configurar GitHub Discussions
3. Obtener IDs desde [giscus.app](https://giscus.app)

### Newsletter Setup

1. Crear cuenta en [Buttondown](https://buttondown.email)
2. Obtener API key
3. Configurar variable de entorno

## 🚀 Despliegue

### Vercel (Recomendado)

1. Conectar repositorio a Vercel
2. Configurar variables de entorno
3. Deploy automático en cada push

### Otros Proveedores

Compatible con cualquier proveedor que soporte Next.js:
- Netlify
- Railway
- DigitalOcean App Platform

## 📊 SEO y Performance

- ✅ Lighthouse Score > 90 en todas las métricas
- ✅ Sitemap.xml automático
- ✅ RSS feed
- ✅ Open Graph tags
- ✅ Structured data (JSON-LD)
- ✅ Robots.txt
- ✅ Metadata optimizada

## 🔒 Seguridad

- Headers de seguridad configurados
- CSP (Content Security Policy)
- HTTPS obligatorio
- Sanitización de contenido MDX

## 📚 Stack Tecnológico

- **Framework**: Next.js 14
- **Language**: TypeScript
- **Styling**: TailwindCSS
- **Content**: MDX + gray-matter
- **Search**: Fuse.js
- **Syntax Highlighting**: rehype-pretty-code
- **Icons**: Lucide React
- **Analytics**: Vercel Analytics
- **Comments**: Giscus
- **Newsletter**: Buttondown

## 📄 Licencia

MIT License - ver [LICENSE](LICENSE) para detalles.

## 🤝 Contribuciones

Las contribuciones son bienvenidas. Por favor:

1. Fork el proyecto
2. Crea una rama para tu feature
3. Commit tus cambios
4. Push a la rama
5. Abre un Pull Request

## 📞 Contacto

- **Blog**: [ronny-cybersec.vercel.app](https://ronny-cybersec.vercel.app)
- **Email**: contacto@ronny-cybersec.com
- **GitHub**: [@ronny](https://github.com/ronny)

---

**Nota**: Este blog tiene fines educativos. Todo el contenido sobre ciberseguridad debe usarse de manera ética y legal.
