"use server"

import fs from "fs/promises"
import path from "path"
import matter from "gray-matter"

export interface BlogPost {
  slug: string
  title: string
  description: string
  date: string
  category: string
  tags: string[]
  readTime: string
  author: string
  content: string
  excerpt: string
}

export interface BlogMetadata {
  title: string
  description: string
  date: string
  category: string
  tags: string[]
  readTime: string
  author: string
}

const postsDirectory = path.join(process.cwd(), "content/posts")

export async function getAllPosts(): Promise<BlogPost[]> {
  try {
    try {
      await fs.access(postsDirectory)
    } catch {
      // Directory doesn't exist, create it
      await fs.mkdir(postsDirectory, { recursive: true })
      return []
    }

    const fileNames = await fs.readdir(postsDirectory)
    const allPostsData = await Promise.all(
      fileNames
        .filter((name) => name.endsWith(".mdx"))
        .map(async (fileName) => {
          const slug = fileName.replace(/\.mdx$/, "")
          const fullPath = path.join(postsDirectory, fileName)
          const fileContents = await fs.readFile(fullPath, "utf8")
          const { data, content } = matter(fileContents)

          return {
            slug,
            title: data.title || "",
            description: data.description || "",
            date: data.date || "",
            category: data.category || "General",
            tags: data.tags || [],
            readTime: data.readTime || "5 min",
            author: data.author || "Ronny",
            content,
            excerpt: data.description || content.slice(0, 160) + "...",
          } as BlogPost
        }),
    )

    return allPostsData.sort((a, b) => (a.date < b.date ? 1 : -1))
  } catch (error) {
    console.error("[v0] Error in getAllPosts:", error)
    return []
  }
}

export async function getPostBySlug(slug: string): Promise<BlogPost | null> {
  try {
    const fullPath = path.join(postsDirectory, `${slug}.mdx`)
    const fileContents = await fs.readFile(fullPath, "utf8")
    const { data, content } = matter(fileContents)

    return {
      slug,
      title: data.title || "",
      description: data.description || "",
      date: data.date || "",
      category: data.category || "General",
      tags: data.tags || [],
      readTime: data.readTime || "5 min",
      author: data.author || "Ronny",
      content,
      excerpt: data.description || content.slice(0, 160) + "...",
    }
  } catch (error) {
    return null
  }
}

export async function getPostsByCategory(category: string): Promise<BlogPost[]> {
  const allPosts = await getAllPosts()
  return allPosts.filter((post) => post.category.toLowerCase() === category.toLowerCase())
}

export async function getPostsByTag(tag: string): Promise<BlogPost[]> {
  const allPosts = await getAllPosts()
  return allPosts.filter((post) => post.tags.some((postTag) => postTag.toLowerCase() === tag.toLowerCase()))
}

export async function getAllCategories(): Promise<string[]> {
  const allPosts = await getAllPosts()
  const categories = allPosts.map((post) => post.category)
  return Array.from(new Set(categories))
}

export async function getAllTags(): Promise<string[]> {
  const allPosts = await getAllPosts()
  const tags = allPosts.flatMap((post) => post.tags)
  return Array.from(new Set(tags))
}
