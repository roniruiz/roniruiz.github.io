import { Navigation } from "@/components/navigation"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ExternalLink, Shield, Terminal, Book, Wrench } from "lucide-react"
import Link from "next/link"

const resourceCategories = [
  {
    title: "Herramientas de Pentesting",
    icon: Wrench,
    resources: [
      {
        name: "Kali Linux",
        description: "Distribución especializada en pentesting con más de 600 herramientas preinstaladas",
        url: "https://www.kali.org/",
        type: "OS",
        free: true,
      },
      {
        name: "Burp Suite",
        description: "Plataforma integrada para testing de seguridad en aplicaciones web",
        url: "https://portswigger.net/burp",
        type: "Web Security",
        free: false,
      },
      {
        name: "Metasploit",
        description: "Framework de penetration testing para desarrollo y ejecución de exploits",
        url: "https://www.metasploit.com/",
        type: "Exploitation",
        free: true,
      },
      {
        name: "Wireshark",
        description: "Analizador de protocolos de red más popular del mundo",
        url: "https://www.wireshark.org/",
        type: "Network Analysis",
        free: true,
      },
    ],
  },
  {
    title: "Recursos de Aprendizaje",
    icon: Book,
    resources: [
      {
        name: "OWASP Top 10",
        description: "Lista de los 10 riesgos de seguridad más críticos en aplicaciones web",
        url: "https://owasp.org/www-project-top-ten/",
        type: "Documentation",
        free: true,
      },
      {
        name: "Cybrary",
        description: "Plataforma de educación en ciberseguridad con cursos gratuitos y premium",
        url: "https://www.cybrary.it/",
        type: "Training",
        free: true,
      },
      {
        name: "SANS Reading Room",
        description: "Biblioteca de papers y whitepapers sobre ciberseguridad",
        url: "https://www.sans.org/reading-room/",
        type: "Research",
        free: true,
      },
      {
        name: "Hack The Box",
        description: "Plataforma de laboratorios virtuales para práctica de pentesting",
        url: "https://www.hackthebox.com/",
        type: "Lab",
        free: false,
      },
    ],
  },
  {
    title: "Laboratorios Virtuales",
    icon: Terminal,
    resources: [
      {
        name: "VulnHub",
        description: "Máquinas virtuales vulnerables para práctica de pentesting",
        url: "https://www.vulnhub.com/",
        type: "VM",
        free: true,
      },
      {
        name: "TryHackMe",
        description: "Plataforma gamificada para aprender ciberseguridad paso a paso",
        url: "https://tryhackme.com/",
        type: "Training",
        free: true,
      },
      {
        name: "OverTheWire",
        description: "Wargames y challenges de seguridad para todos los niveles",
        url: "https://overthewire.org/wargames/",
        type: "Challenges",
        free: true,
      },
      {
        name: "PentesterLab",
        description: "Ejercicios hands-on para aprender web application security",
        url: "https://pentesterlab.com/",
        type: "Web Security",
        free: false,
      },
    ],
  },
  {
    title: "Certificaciones",
    icon: Shield,
    resources: [
      {
        name: "OSCP",
        description: "Offensive Security Certified Professional - Certificación práctica de pentesting",
        url: "https://www.offensive-security.com/pwk-oscp/",
        type: "Certification",
        free: false,
      },
      {
        name: "CEH",
        description: "Certified Ethical Hacker - Certificación reconocida mundialmente",
        url: "https://www.eccouncil.org/programs/certified-ethical-hacker-ceh/",
        type: "Certification",
        free: false,
      },
      {
        name: "CISSP",
        description: "Certified Information Systems Security Professional",
        url: "https://www.isc2.org/Certifications/CISSP",
        type: "Certification",
        free: false,
      },
      {
        name: "CompTIA Security+",
        description: "Certificación fundamental en ciberseguridad",
        url: "https://www.comptia.org/certifications/security",
        type: "Certification",
        free: false,
      },
    ],
  },
]

export default function ResourcesPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="ml-64 p-8">
        <div className="max-w-6xl">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-4">Recursos de Ciberseguridad</h1>
            <p className="text-muted-foreground text-lg">
              Colección curada de herramientas, plataformas de aprendizaje y recursos esenciales para profesionales de
              la ciberseguridad.
            </p>
          </div>

          {/* Resource Categories */}
          {resourceCategories.map((category) => (
            <section key={category.title} className="mb-12">
              <div className="flex items-center space-x-3 mb-6">
                <div className="flex items-center justify-center w-10 h-10 bg-primary/10 rounded-lg border border-primary/20">
                  <category.icon className="w-6 h-6 text-primary" />
                </div>
                <h2 className="text-2xl font-bold text-foreground">{category.title}</h2>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {category.resources.map((resource) => (
                  <Card key={resource.name} className="group hover:border-primary/50 transition-colors">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="group-hover:text-primary transition-colors flex items-center space-x-2">
                            <span>{resource.name}</span>
                            {resource.free && (
                              <Badge variant="secondary" className="text-xs">
                                Gratis
                              </Badge>
                            )}
                          </CardTitle>
                          <div className="flex items-center space-x-2 mt-2">
                            <Badge variant="outline" className="text-xs">
                              {resource.type}
                            </Badge>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm" asChild>
                          <Link href={resource.url} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="w-4 h-4" />
                          </Link>
                        </Button>
                      </div>
                      <CardDescription className="text-sm leading-relaxed">{resource.description}</CardDescription>
                    </CardHeader>
                  </Card>
                ))}
              </div>
            </section>
          ))}

          {/* Additional Resources */}
          <section className="mt-16 p-6 bg-muted/50 rounded-lg border border-border">
            <h3 className="text-xl font-semibold text-foreground mb-4">¿Conoces algún recurso útil?</h3>
            <p className="text-muted-foreground mb-4">
              Si tienes sugerencias de herramientas, plataformas o recursos que deberían estar en esta lista, no dudes
              en contactarme.
            </p>
            <Button asChild>
              <Link href="/contact">Sugerir recurso</Link>
            </Button>
          </section>
        </div>
      </main>
    </div>
  )
}
