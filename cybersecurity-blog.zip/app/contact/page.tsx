"use client"

import type React from "react"

import { useState } from "react"
import { Navigation } from "@/components/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Mail, MessageSquare, Github, Linkedin, Twitter, Send, MapPin, Clock, Shield } from "lucide-react"
import Link from "next/link"

const contactMethods = [
  {
    icon: Mail,
    title: "Email",
    description: "Para consultas profesionales y colaboraciones",
    value: "ronny@cybersec.dev",
    href: "mailto:ronny@cybersec.dev",
  },
  {
    icon: Github,
    title: "GitHub",
    description: "Revisa mis proyectos y contribuciones",
    value: "@ronny-cybersec",
    href: "https://github.com/ronny-cybersec",
  },
  {
    icon: Linkedin,
    title: "LinkedIn",
    description: "Conecta conmigo profesionalmente",
    value: "Ronny - Cybersecurity Engineer",
    href: "https://linkedin.com/in/ronny-cybersec",
  },
  {
    icon: Twitter,
    title: "Twitter",
    description: "Sígueme para updates sobre ciberseguridad",
    value: "@ronny_cybersec",
    href: "https://twitter.com/ronny_cybersec",
  },
]

const faqs = [
  {
    question: "¿Realizas auditorías de seguridad freelance?",
    answer:
      "Sí, ofrezco servicios de consultoría en ciberseguridad incluyendo pentesting, auditorías de código y evaluaciones de seguridad. Contacta para discutir tu proyecto específico.",
  },
  {
    question: "¿Puedo usar tus herramientas en mi empresa?",
    answer:
      "La mayoría de mis herramientas son open source bajo licencias permisivas. Revisa la documentación específica de cada proyecto en GitHub para detalles de licenciamiento.",
  },
  {
    question: "¿Ofreces capacitación en ciberseguridad?",
    answer:
      "Ocasionalmente ofrezco workshops y capacitaciones especializadas. Si tu organización está interesada, envía un email con los detalles de tus necesidades.",
  },
  {
    question: "¿Cómo puedo contribuir a tus proyectos?",
    answer:
      "¡Las contribuciones son bienvenidas! Revisa los issues abiertos en GitHub, propón mejoras o reporta bugs. También puedes sugerir nuevas funcionalidades.",
  },
]

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send the form data to your backend
    console.log("Form submitted:", formData)
    // Reset form or show success message
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }))
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="ml-64 p-8">
        <div className="max-w-6xl">
          {/* Header */}
          <div className="mb-12">
            <h1 className="text-3xl font-bold text-foreground mb-4">Contacto</h1>
            <p className="text-muted-foreground text-lg">
              ¿Tienes una pregunta, propuesta de colaboración o simplemente quieres charlar sobre ciberseguridad? Me
              encantaría escucharte.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Contact Form */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <MessageSquare className="w-5 h-5 text-primary" />
                    <span>Envía un mensaje</span>
                  </CardTitle>
                  <CardDescription>Completa el formulario y te responderé lo antes posible.</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Nombre</Label>
                        <Input
                          id="name"
                          name="name"
                          value={formData.name}
                          onChange={handleChange}
                          placeholder="Tu nombre completo"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleChange}
                          placeholder="tu@email.com"
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="subject">Asunto</Label>
                      <Input
                        id="subject"
                        name="subject"
                        value={formData.subject}
                        onChange={handleChange}
                        placeholder="¿De qué quieres hablar?"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="message">Mensaje</Label>
                      <Textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        placeholder="Cuéntame más detalles sobre tu consulta o propuesta..."
                        rows={6}
                        required
                      />
                    </div>

                    <Button type="submit" className="w-full">
                      <Send className="w-4 h-4 mr-2" />
                      Enviar mensaje
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Contact Methods & Info */}
            <div className="space-y-6">
              {/* Contact Methods */}
              <Card>
                <CardHeader>
                  <CardTitle>Otras formas de contacto</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {contactMethods.map((method) => (
                    <Link
                      key={method.title}
                      href={method.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-start space-x-3 p-3 rounded-lg hover:bg-muted/50 transition-colors group"
                    >
                      <div className="flex items-center justify-center w-10 h-10 bg-primary/10 rounded-lg border border-primary/20 group-hover:border-primary/40 transition-colors">
                        <method.icon className="w-5 h-5 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-foreground group-hover:text-primary transition-colors">
                          {method.title}
                        </h4>
                        <p className="text-xs text-muted-foreground mb-1">{method.description}</p>
                        <p className="text-sm text-primary font-mono">{method.value}</p>
                      </div>
                    </Link>
                  ))}
                </CardContent>
              </Card>

              {/* Availability */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Clock className="w-5 h-5 text-primary" />
                    <span>Disponibilidad</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">UTC-3 (Argentina)</span>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    <p>• Respuesta típica: 24-48 horas</p>
                    <p>• Consultas urgentes: Especificar en asunto</p>
                    <p>• Disponible para llamadas: Previa coordinación</p>
                  </div>
                </CardContent>
              </Card>

              {/* Security Note */}
              <Card className="border-primary/20 bg-primary/5">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-primary">
                    <Shield className="w-5 h-5" />
                    <span>Nota de Seguridad</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Para comunicaciones sensibles o confidenciales, considera usar PGP. Mi clave pública está disponible
                    en mi perfil de GitHub.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* FAQ Section */}
          <section className="mt-16">
            <h2 className="text-2xl font-bold text-foreground mb-6">Preguntas Frecuentes</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {faqs.map((faq, index) => (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle className="text-lg">{faq.question}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground leading-relaxed">{faq.answer}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>
        </div>
      </main>
    </div>
  )
}
