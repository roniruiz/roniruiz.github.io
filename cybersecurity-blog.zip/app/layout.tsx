import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import { JetBrains_Mono } from "next/font/google"
import { Suspense } from "react"
import { Analytics } from "@vercel/analytics/react"
import { StructuredData } from "@/components/structured-data"
import "./globals.css"

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
})

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-jetbrains-mono",
})

export const metadata: Metadata = {
  title: "RONNY | Sistemas & Ciberseguridad",
  description:
    "Tutoriales, guías y proyectos de ciberseguridad con enfoque educativo y ético. Por Ronny, Ingeniero en Sistemas.",
  generator: "Next.js",
  keywords: [
    "ciberseguridad",
    "pentesting",
    "kali linux",
    "nmap",
    "wifi segura",
    "sistemas",
    "hacking ético",
    "tutoriales",
  ],
  authors: [{ name: "Ronny", url: "https://ronny-cybersec.vercel.app" }],
  creator: "Ronny",
  publisher: "Ronny",
  metadataBase: new URL("https://ronny-cybersec.vercel.app"),
  alternates: {
    canonical: "/",
    types: {
      "application/rss+xml": [{ url: "/rss", title: "RONNY | RSS Feed" }],
    },
  },
  openGraph: {
    title: "RONNY | Sistemas & Ciberseguridad",
    description: "Tutoriales, guías y proyectos de ciberseguridad con enfoque educativo y ético",
    type: "website",
    locale: "es_ES",
    url: "https://ronny-cybersec.vercel.app",
    siteName: "RONNY | Sistemas & Ciberseguridad",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "RONNY | Sistemas & Ciberseguridad",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "RONNY | Sistemas & Ciberseguridad",
    description: "Tutoriales, guías y proyectos de ciberseguridad con enfoque educativo y ético",
    images: ["/og-image.png"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es" className="dark">
      <head>
        <StructuredData />
      </head>
      <body className={`font-sans ${inter.variable} ${jetbrainsMono.variable} antialiased`}>
        <Suspense fallback={null}>{children}</Suspense>
        <Analytics />
      </body>
    </html>
  )
}
