import { getAllPosts, getAllCategories, getAllTags } from "@/lib/blog"
import { Navigation } from "@/components/navigation"
import { ArticlesClient } from "@/components/articles-client"

export default async function ArticlesPage() {
  const posts = await getAllPosts()
  const categories = await getAllCategories()
  const tags = await getAllTags()

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <ArticlesClient posts={posts} categories={categories} tags={tags} />
    </div>
  )
}
