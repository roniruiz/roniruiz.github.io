import { getPostBySlug, getAllPosts } from "@/lib/blog"
import { Navigation } from "@/components/navigation"
import { mdxComponents } from "@/components/mdx-components"
import { GiscusComments } from "@/components/giscus-comments"
import { NewsletterSignup } from "@/components/newsletter-signup"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Calendar, Clock, ArrowLeft, Share2, User } from "lucide-react"
import Link from "next/link"
import { notFound } from "next/navigation"
import { MDXRemote } from "next-mdx-remote/rsc"

interface PageProps {
  params: {
    slug: string
  }
}

export async function generateStaticParams() {
  const posts = await getAllPosts()
  return posts.map((post) => ({
    slug: post.slug,
  }))
}

export async function generateMetadata({ params }: PageProps) {
  const post = await getPostBySlug(params.slug)

  if (!post) {
    return {
      title: "Artículo no encontrado",
    }
  }

  return {
    title: `${post.title} | Ronny's Cybersecurity Blog`,
    description: post.description,
    keywords: post.tags.join(", "),
    authors: [{ name: post.author }],
    openGraph: {
      title: post.title,
      description: post.description,
      type: "article",
      publishedTime: post.date,
      authors: [post.author],
      tags: post.tags,
    },
    twitter: {
      card: "summary_large_image",
      title: post.title,
      description: post.description,
    },
  }
}

export default async function ArticlePage({ params }: PageProps) {
  const post = await getPostBySlug(params.slug)

  if (!post) {
    notFound()
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="ml-64 p-8">
        <div className="max-w-4xl">
          {/* Back Button */}
          <div className="mb-6">
            <Button variant="ghost" asChild>
              <Link href="/articles">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Volver a artículos
              </Link>
            </Button>
          </div>

          {/* Article Header */}
          <header className="mb-8">
            <div className="flex items-center space-x-2 mb-4">
              <Badge variant="secondary">{post.category}</Badge>
              {post.tags.map((tag) => (
                <Badge key={tag} variant="outline" className="text-xs">
                  {tag}
                </Badge>
              ))}
            </div>

            <h1 className="text-4xl font-bold text-foreground mb-4 leading-tight">{post.title}</h1>

            <p className="text-xl text-muted-foreground mb-6 leading-relaxed">{post.description}</p>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                <div className="flex items-center">
                  <User className="w-4 h-4 mr-2" />
                  {post.author}
                </div>
                <div className="flex items-center">
                  <Calendar className="w-4 h-4 mr-2" />
                  {new Date(post.date).toLocaleDateString("es-ES", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </div>
                <div className="flex items-center">
                  <Clock className="w-4 h-4 mr-2" />
                  {post.readTime}
                </div>
              </div>

              <Button variant="outline" size="sm">
                <Share2 className="w-4 h-4 mr-2" />
                Compartir
              </Button>
            </div>
          </header>

          <Separator className="mb-8" />

          {/* Article Content */}
          <article className="prose prose-lg max-w-none">
            <MDXRemote source={post.content} components={mdxComponents} />
          </article>

          {/* Newsletter Signup */}
          <section className="mt-12">
            <NewsletterSignup
              title="¿Te gustó este artículo?"
              description="Suscríbete para recibir más contenido sobre ciberseguridad, técnicas de pentesting y las últimas amenazas."
            />
          </section>

          <GiscusComments slug={params.slug} />

          {/* Article Footer */}
          <footer className="mt-12 pt-8 border-t border-border">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold mb-2">¿Te gustó este artículo?</h3>
                <p className="text-sm text-muted-foreground">Compártelo con otros profesionales de la ciberseguridad</p>
              </div>
              <Button>
                <Share2 className="w-4 h-4 mr-2" />
                Compartir artículo
              </Button>
            </div>
          </footer>
        </div>
      </main>
    </div>
  )
}
