import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { email } = await request.json()

    if (!email || !email.includes("@")) {
      return NextResponse.json({ error: "Email válido requerido" }, { status: 400 })
    }

    // Buttondown API integration
    const BUTTONDOWN_API_KEY = process.env.BUTTONDOWN_API_KEY

    if (!BUTTONDOWN_API_KEY) {
      console.error("BUTTONDOWN_API_KEY not configured")
      return NextResponse.json({ error: "Servicio no disponible temporalmente" }, { status: 500 })
    }

    const response = await fetch("https://api.buttondown.email/v1/subscribers", {
      method: "POST",
      headers: {
        Authorization: `Token ${BUTTONDOWN_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email,
        tags: ["cybersecurity-blog"],
        metadata: {
          source: "blog-signup",
          timestamp: new Date().toISOString(),
        },
      }),
    })

    const data = await response.json()

    if (response.ok) {
      return NextResponse.json({
        success: true,
        message: "Suscripción exitosa",
      })
    } else {
      // Handle specific Buttondown errors
      if (response.status === 400 && data.email) {
        return NextResponse.json(
          {
            error: "Este email ya está suscrito",
          },
          { status: 400 },
        )
      }

      return NextResponse.json(
        {
          error: "Error al procesar suscripción",
        },
        { status: 500 },
      )
    }
  } catch (error) {
    console.error("Newsletter subscription error:", error)
    return NextResponse.json(
      {
        error: "Error interno del servidor",
      },
      { status: 500 },
    )
  }
}
