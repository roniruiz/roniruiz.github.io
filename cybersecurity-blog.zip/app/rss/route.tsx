import { getAllPosts } from "@/lib/blog"
import { NextResponse } from "next/server"

export async function GET() {
  const posts = await getAllPosts()

  const rssXml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>RONNY | Sistemas &amp; Ciberseguridad</title>
    <description>Tutoriales, guías y proyectos de ciberseguridad con enfoque educativo y ético</description>
    <link>https://ronny-cybersec.vercel.app</link>
    <language>es</language>
    <atom:link href="https://ronny-cybersec.vercel.app/rss" rel="self" type="application/rss+xml"/>
    <lastBuildDate>${new Date().toUTCString()}</lastBuildDate>
    
    ${posts
      .map(
        (post) => `
    <item>
      <title>${post.title}</title>
      <description>${post.description}</description>
      <link>https://ronny-cybersec.vercel.app/articles/${post.slug}</link>
      <guid>https://ronny-cybersec.vercel.app/articles/${post.slug}</guid>
      <pubDate>${new Date(post.date).toUTCString()}</pubDate>
      <category>${post.category}</category>
    </item>
    `,
      )
      .join("")}
  </channel>
</rss>`

  return new NextResponse(rssXml, {
    headers: {
      "Content-Type": "application/xml",
      "Cache-Control": "public, s-maxage=86400, stale-while-revalidate",
    },
  })
}
