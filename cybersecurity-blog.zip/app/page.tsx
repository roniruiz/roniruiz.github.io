import { TerminalHero } from "@/components/terminal-hero"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { NewsletterSignup } from "@/components/newsletter-signup"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Icons } from "@/components/icons"
import Link from "next/link"

// Demo posts data
const recentPosts = [
  {
    id: 1,
    title: "Guía Completa de Kali Linux para Principiantes",
    excerpt: "Todo lo que necesitas saber para comenzar con Kali Linux en pentesting y auditorías de seguridad.",
    category: "Herramientas",
    date: "2024-01-15",
    readTime: "8 min",
    tags: ["Kali Linux", "Pentesting", "Principiantes"],
  },
  {
    id: 2,
    title: "Dominando Nmap: Técnicas Avanzadas de Reconocimiento",
    excerpt: "Explora técnicas avanzadas de escaneo con Nmap para reconocimiento efectivo en auditorías de seguridad.",
    category: "Reconocimiento",
    date: "2024-01-10",
    readTime: "12 min",
    tags: ["Nmap", "Reconocimiento", "Network Security"],
  },
  {
    id: 3,
    title: "Configuración Segura de Redes WiFi Empresariales",
    excerpt: "Mejores prácticas para implementar y mantener redes WiFi seguras en entornos empresariales.",
    category: "Network Security",
    date: "2024-01-05",
    readTime: "10 min",
    tags: ["WiFi", "WPA3", "Enterprise Security"],
  },
]

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="ml-64">
        <div className="p-8">
          {/* Hero Section */}
          <section className="py-12">
            <div className="max-w-4xl">
              <TerminalHero />
              <div className="mt-8">
                <h1 className="text-4xl font-bold text-foreground mb-4">
                  Explorando el mundo de la <span className="terminal-text">Ciberseguridad</span>
                </h1>
                <p className="text-xl text-muted-foreground mb-6 leading-relaxed">
                  Bienvenido a mi espacio digital donde comparto conocimientos sobre seguridad informática, pentesting,
                  y las últimas tendencias en ciberseguridad. Desde técnicas de hacking ético hasta implementación de
                  defensas robustas.
                </p>
                <div className="flex space-x-4">
                  <Button asChild className="glow-effect">
                    <Link href="/articles">
                      Explorar Artículos <Icons.ArrowRight className="ml-2 w-4 h-4" />
                    </Link>
                  </Button>
                  <Button variant="outline" asChild>
                    <Link href="/about">Conoce más sobre mí</Link>
                  </Button>
                </div>
              </div>
            </div>
          </section>

          {/* Recent Posts */}
          <section className="py-12">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold text-foreground">Artículos Recientes</h2>
              <Button variant="ghost" asChild>
                <Link href="/articles" className="text-primary hover:text-primary/80">
                  Ver todos <Icons.ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {recentPosts.map((post) => (
                <Card key={post.id} className="group hover:border-primary/50 transition-colors">
                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="secondary" className="text-xs">
                        {post.category}
                      </Badge>
                      <div className="flex items-center text-xs text-muted-foreground">
                        <Icons.Calendar className="w-3 h-3 mr-1" />
                        {new Date(post.date).toLocaleDateString("es-ES")}
                      </div>
                    </div>
                    <CardTitle className="group-hover:text-primary transition-colors">
                      <Link href={`/articles/${post.id}`}>{post.title}</Link>
                    </CardTitle>
                    <CardDescription className="text-sm leading-relaxed">{post.excerpt}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div className="flex flex-wrap gap-1">
                        {post.tags.slice(0, 2).map((tag) => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                      <span className="text-xs text-muted-foreground">{post.readTime}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          {/* Featured Categories */}
          <section className="py-12">
            <h2 className="text-2xl font-bold text-foreground mb-8">Categorías Principales</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="text-center p-6 hover:border-primary/50 transition-colors group">
                <Icons.Shield className="w-12 h-12 text-primary mx-auto mb-4 group-hover:scale-110 transition-transform" />
                <h3 className="text-lg font-semibold mb-2">Pentesting</h3>
                <p className="text-sm text-muted-foreground">Técnicas y herramientas para auditorías de seguridad</p>
              </Card>
              <Card className="text-center p-6 hover:border-primary/50 transition-colors group">
                <Icons.Lock className="w-12 h-12 text-secondary mx-auto mb-4 group-hover:scale-110 transition-transform" />
                <h3 className="text-lg font-semibold mb-2">Hardening</h3>
                <p className="text-sm text-muted-foreground">Fortificación y securización de sistemas</p>
              </Card>
              <Card className="text-center p-6 hover:border-primary/50 transition-colors group">
                <Icons.Wifi className="w-12 h-12 text-primary mx-auto mb-4 group-hover:scale-110 transition-transform" />
                <h3 className="text-lg font-semibold mb-2">Network Security</h3>
                <p className="text-sm text-muted-foreground">Seguridad en redes y comunicaciones</p>
              </Card>
            </div>
          </section>

          {/* Newsletter CTA */}
          <section className="py-12">
            <div className="max-w-2xl mx-auto">
              <NewsletterSignup />
            </div>
          </section>
        </div>

        <Footer />
      </main>
    </div>
  )
}
