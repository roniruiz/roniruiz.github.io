import { Navigation } from "@/components/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Shield, Code, Award, BookOpen, Users, Target } from "lucide-react"
import Link from "next/link"

const skills = [
  { name: "Penetration Testing", level: 95, category: "Security" },
  { name: "Network Security", level: 90, category: "Security" },
  { name: "Web Application Security", level: 88, category: "Security" },
  { name: "Incident Response", level: 85, category: "Security" },
  { name: "Python", level: 92, category: "Programming" },
  { name: "Linux/Unix", level: 90, category: "Systems" },
  { name: "Docker/Kubernetes", level: 80, category: "DevOps" },
  { name: "Cloud Security (AWS/Azure)", level: 75, category: "Cloud" },
]

const certifications = [
  {
    name: "OSCP",
    fullName: "Offensive Security Certified Professional",
    issuer: "Offensive Security",
    year: "2023",
    status: "Activa",
  },
  {
    name: "CEH",
    fullName: "Certified Ethical Hacker",
    issuer: "EC-Council",
    year: "2022",
    status: "Activa",
  },
  {
    name: "CISSP",
    fullName: "Certified Information Systems Security Professional",
    issuer: "ISC2",
    year: "2021",
    status: "Activa",
  },
  {
    name: "AWS Security Specialty",
    fullName: "AWS Certified Security - Specialty",
    issuer: "Amazon Web Services",
    year: "2023",
    status: "Activa",
  },
]

const experience = [
  {
    title: "Senior Security Engineer",
    company: "TechCorp Solutions",
    period: "2022 - Presente",
    description:
      "Liderazgo de iniciativas de seguridad empresarial, incluyendo pentesting, respuesta a incidentes y desarrollo de políticas de seguridad.",
    achievements: [
      "Reducción del 40% en vulnerabilidades críticas",
      "Implementación de programa de bug bounty interno",
      "Desarrollo de herramientas de automatización de seguridad",
    ],
  },
  {
    title: "Cybersecurity Analyst",
    company: "SecureNet Inc.",
    period: "2020 - 2022",
    description:
      "Análisis de amenazas, monitoreo de seguridad 24/7 y respuesta a incidentes de seguridad para clientes empresariales.",
    achievements: [
      "Detección y mitigación de 150+ incidentes de seguridad",
      "Desarrollo de playbooks de respuesta a incidentes",
      "Capacitación de equipos junior en técnicas de análisis",
    ],
  },
  {
    title: "Junior Penetration Tester",
    company: "CyberDefense Labs",
    period: "2019 - 2020",
    description:
      "Realización de pruebas de penetración en aplicaciones web, redes y sistemas para identificar vulnerabilidades.",
    achievements: [
      "Completación de 50+ auditorías de seguridad",
      "Especialización en testing de aplicaciones web",
      "Desarrollo de metodologías de testing automatizado",
    ],
  },
]

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="ml-64 p-8">
        <div className="max-w-4xl">
          {/* Header */}
          <div className="mb-12">
            <div className="flex items-start space-x-6">
              <div className="w-32 h-32 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-lg border border-primary/20 flex items-center justify-center">
                <Shield className="w-16 h-16 text-primary" />
              </div>
              <div className="flex-1">
                <h1 className="text-4xl font-bold text-foreground mb-4">Ronny</h1>
                <p className="text-xl text-primary mb-2">Ingeniero en Sistemas | Especialista en Ciberseguridad</p>
                <p className="text-muted-foreground leading-relaxed">
                  Profesional apasionado por la ciberseguridad con más de 5 años de experiencia en pentesting, análisis
                  de vulnerabilidades y respuesta a incidentes. Comprometido con la protección de infraestructuras
                  críticas y la educación en seguridad informática.
                </p>
              </div>
            </div>
          </div>

          {/* Mission Statement */}
          <section className="mb-12">
            <Card className="bg-muted/50 border-primary/20">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Target className="w-5 h-5 text-primary" />
                  <span>Misión</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">
                  Mi objetivo es contribuir a un ciberespacio más seguro mediante la identificación proactiva de
                  vulnerabilidades, el desarrollo de soluciones de seguridad innovadoras y la educación de la próxima
                  generación de profesionales en ciberseguridad. Creo firmemente en el poder del conocimiento compartido
                  y la colaboración ética para fortalecer nuestras defensas digitales.
                </p>
              </CardContent>
            </Card>
          </section>

          {/* Skills */}
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-foreground mb-6 flex items-center space-x-2">
              <Code className="w-6 h-6 text-primary" />
              <span>Habilidades Técnicas</span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {skills.map((skill) => (
                <div key={skill.name} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-foreground">{skill.name}</span>
                    <Badge variant="outline" className="text-xs">
                      {skill.category}
                    </Badge>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div
                      className="bg-primary h-2 rounded-full transition-all duration-300"
                      style={{ width: `${skill.level}%` }}
                    ></div>
                  </div>
                  <div className="text-xs text-muted-foreground text-right">{skill.level}%</div>
                </div>
              ))}
            </div>
          </section>

          {/* Certifications */}
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-foreground mb-6 flex items-center space-x-2">
              <Award className="w-6 h-6 text-primary" />
              <span>Certificaciones</span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {certifications.map((cert) => (
                <Card key={cert.name} className="hover:border-primary/50 transition-colors">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{cert.name}</CardTitle>
                      <Badge variant="secondary" className="text-xs">
                        {cert.year}
                      </Badge>
                    </div>
                    <CardDescription className="text-sm">{cert.fullName}</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">{cert.issuer}</span>
                      <Badge variant="outline" className="text-xs text-green-600 border-green-600">
                        {cert.status}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          {/* Experience */}
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-foreground mb-6 flex items-center space-x-2">
              <Users className="w-6 h-6 text-primary" />
              <span>Experiencia Profesional</span>
            </h2>
            <div className="space-y-6">
              {experience.map((job, index) => (
                <Card key={index} className="hover:border-primary/50 transition-colors">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{job.title}</CardTitle>
                        <CardDescription className="text-primary font-medium">{job.company}</CardDescription>
                      </div>
                      <Badge variant="outline">{job.period}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed">{job.description}</p>
                  </CardHeader>
                  <CardContent>
                    <h4 className="text-sm font-medium text-foreground mb-2">Logros principales:</h4>
                    <ul className="space-y-1">
                      {job.achievements.map((achievement, i) => (
                        <li key={i} className="text-sm text-muted-foreground flex items-start">
                          <span className="text-primary mr-2">•</span>
                          {achievement}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          {/* Education & Learning */}
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-foreground mb-6 flex items-center space-x-2">
              <BookOpen className="w-6 h-6 text-primary" />
              <span>Educación y Aprendizaje Continuo</span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Educación Formal</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <h4 className="font-medium text-foreground">Ingeniería en Sistemas</h4>
                    <p className="text-sm text-muted-foreground">Universidad Tecnológica Nacional</p>
                    <p className="text-xs text-muted-foreground">2015 - 2019</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Aprendizaje Continuo</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="text-sm text-muted-foreground">
                    <p>• Cursos especializados en SANS Institute</p>
                    <p>• Participación en conferencias de ciberseguridad</p>
                    <p>• Investigación independiente en nuevas amenazas</p>
                    <p>• Contribución a proyectos open source</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </section>

          {/* Contact CTA */}
          <section className="text-center p-6 bg-muted/50 rounded-lg border border-border">
            <h3 className="text-xl font-semibold text-foreground mb-4">¿Quieres colaborar o tienes alguna pregunta?</h3>
            <p className="text-muted-foreground mb-6">
              Estoy siempre abierto a nuevas oportunidades, colaboraciones y conversaciones sobre ciberseguridad.
            </p>
            <div className="flex justify-center space-x-4">
              <Button asChild>
                <Link href="/contact">Contactar</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link href="/projects">Ver Proyectos</Link>
              </Button>
            </div>
          </section>
        </div>
      </main>
    </div>
  )
}
