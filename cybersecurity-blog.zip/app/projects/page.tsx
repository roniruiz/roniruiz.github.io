import { Navigation } from "@/components/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ExternalLink, Github, Calendar, Code, Shield, Network, Lock, Zap } from "lucide-react"
import Link from "next/link"

const projects = [
  {
    id: 1,
    title: "Network Security Scanner",
    description:
      "Herramienta automatizada para escaneo y análisis de vulnerabilidades en redes corporativas. Incluye detección de puertos abiertos, servicios vulnerables y configuraciones inseguras.",
    longDescription:
      "Scanner desarrollado en Python que combina múltiples técnicas de reconocimiento para proporcionar un análisis completo de la superficie de ataque de una red. Integra Nmap, análisis de certificados SSL y detección de configuraciones por defecto.",
    technologies: ["Python", "Nmap", "Scapy", "SQLite", "Flask"],
    category: "Network Security",
    status: "Completado",
    date: "2024-01-20",
    github: "https://github.com/ronny/network-scanner",
    demo: "https://demo.network-scanner.com",
    icon: Network,
    featured: true,
  },
  {
    id: 2,
    title: "WiFi Security Auditor",
    description:
      "Suite de herramientas para auditoría de seguridad en redes inalámbricas. Detecta configuraciones inseguras, rogue access points y vulnerabilidades en protocolos WiFi.",
    longDescription:
      "Conjunto de scripts y herramientas para realizar auditorías completas de seguridad WiFi. Incluye detección de Evil Twins, análisis de handshakes WPA/WPA2, y generación de reportes automatizados.",
    technologies: ["Python", "Aircrack-ng", "Scapy", "Matplotlib", "Tkinter"],
    category: "Wireless Security",
    status: "En desarrollo",
    date: "2024-01-15",
    github: "https://github.com/ronny/wifi-auditor",
    demo: null,
    icon: Zap,
    featured: true,
  },
  {
    id: 3,
    title: "Vulnerability Management Dashboard",
    description:
      "Dashboard web para gestión centralizada de vulnerabilidades. Integra múltiples scanners y proporciona métricas de riesgo en tiempo real.",
    longDescription:
      "Plataforma web desarrollada con React y Node.js que centraliza la gestión de vulnerabilidades de múltiples fuentes. Incluye sistema de tickets, métricas de SLA y reportes ejecutivos.",
    technologies: ["React", "Node.js", "MongoDB", "Docker", "OpenVAS API"],
    category: "Vulnerability Management",
    status: "Completado",
    date: "2023-12-10",
    github: "https://github.com/ronny/vuln-dashboard",
    demo: "https://demo.vuln-dashboard.com",
    icon: Shield,
    featured: false,
  },
  {
    id: 4,
    title: "Incident Response Toolkit",
    description:
      "Conjunto de scripts y herramientas para respuesta rápida a incidentes de seguridad. Automatiza la recolección de evidencias y análisis forense básico.",
    longDescription:
      "Toolkit desarrollado para equipos de respuesta a incidentes que automatiza tareas comunes como recolección de logs, análisis de memoria, y preservación de evidencias digitales.",
    technologies: ["PowerShell", "Python", "Volatility", "YARA", "Elasticsearch"],
    category: "Incident Response",
    status: "En desarrollo",
    date: "2024-01-05",
    github: "https://github.com/ronny/ir-toolkit",
    demo: null,
    icon: Lock,
    featured: false,
  },
  {
    id: 5,
    title: "Phishing Detection Engine",
    description:
      "Motor de detección de phishing basado en machine learning. Analiza URLs, contenido y metadatos para identificar sitios maliciosos.",
    longDescription:
      "Sistema de detección que utiliza algoritmos de machine learning para identificar sitios de phishing. Incluye análisis de DOM, certificados SSL, y patrones de comportamiento.",
    technologies: ["Python", "TensorFlow", "BeautifulSoup", "Redis", "FastAPI"],
    category: "Threat Detection",
    status: "Prototipo",
    date: "2023-11-20",
    github: "https://github.com/ronny/phishing-detector",
    demo: null,
    icon: Code,
    featured: false,
  },
]

const categories = [
  "Todos",
  "Network Security",
  "Wireless Security",
  "Vulnerability Management",
  "Incident Response",
  "Threat Detection",
]

export default function ProjectsPage() {
  const featuredProjects = projects.filter((project) => project.featured)
  const otherProjects = projects.filter((project) => !project.featured)

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="ml-64 p-8">
        <div className="max-w-6xl">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-4">Proyectos de Ciberseguridad</h1>
            <p className="text-muted-foreground text-lg">
              Colección de herramientas y proyectos desarrollados para mejorar la postura de seguridad y automatizar
              tareas de ciberseguridad.
            </p>
          </div>

          {/* Categories Filter */}
          <div className="mb-8">
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Badge key={category} variant="outline" className="cursor-pointer hover:bg-primary/10">
                  {category}
                </Badge>
              ))}
            </div>
          </div>

          {/* Featured Projects */}
          {featuredProjects.length > 0 && (
            <section className="mb-12">
              <h2 className="text-2xl font-bold text-foreground mb-6">Proyectos Destacados</h2>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {featuredProjects.map((project) => (
                  <Card key={project.id} className="group hover:border-primary/50 transition-colors">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="flex items-center justify-center w-12 h-12 bg-primary/10 rounded-lg border border-primary/20">
                            <project.icon className="w-6 h-6 text-primary" />
                          </div>
                          <div>
                            <CardTitle className="group-hover:text-primary transition-colors">
                              {project.title}
                            </CardTitle>
                            <div className="flex items-center space-x-2 mt-1">
                              <Badge variant="secondary" className="text-xs">
                                {project.category}
                              </Badge>
                              <Badge
                                variant={project.status === "Completado" ? "default" : "outline"}
                                className="text-xs"
                              >
                                {project.status}
                              </Badge>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center text-xs text-muted-foreground">
                          <Calendar className="w-3 h-3 mr-1" />
                          {new Date(project.date).toLocaleDateString("es-ES")}
                        </div>
                      </div>
                      <CardDescription className="text-sm leading-relaxed mt-4">
                        {project.longDescription}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {/* Technologies */}
                        <div>
                          <h4 className="text-sm font-medium text-foreground mb-2">Tecnologías</h4>
                          <div className="flex flex-wrap gap-1">
                            {project.technologies.map((tech) => (
                              <Badge key={tech} variant="outline" className="text-xs">
                                {tech}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm" asChild>
                            <Link href={project.github} target="_blank" rel="noopener noreferrer">
                              <Github className="w-4 h-4 mr-2" />
                              Código
                            </Link>
                          </Button>
                          {project.demo && (
                            <Button size="sm" asChild>
                              <Link href={project.demo} target="_blank" rel="noopener noreferrer">
                                <ExternalLink className="w-4 h-4 mr-2" />
                                Demo
                              </Link>
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>
          )}

          {/* Other Projects */}
          <section>
            <h2 className="text-2xl font-bold text-foreground mb-6">Otros Proyectos</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {otherProjects.map((project) => (
                <Card key={project.id} className="group hover:border-primary/50 transition-colors">
                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="secondary" className="text-xs">
                        {project.category}
                      </Badge>
                      <div className="flex items-center text-xs text-muted-foreground">
                        <Calendar className="w-3 h-3 mr-1" />
                        {new Date(project.date).toLocaleDateString("es-ES")}
                      </div>
                    </div>
                    <CardTitle className="group-hover:text-primary transition-colors flex items-center space-x-2">
                      <project.icon className="w-5 h-5" />
                      <span>{project.title}</span>
                    </CardTitle>
                    <CardDescription className="text-sm leading-relaxed">{project.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Badge variant={project.status === "Completado" ? "default" : "outline"} className="text-xs">
                          {project.status}
                        </Badge>
                        <div className="flex space-x-1">
                          <Button variant="ghost" size="sm" asChild>
                            <Link href={project.github} target="_blank" rel="noopener noreferrer">
                              <Github className="w-4 h-4" />
                            </Link>
                          </Button>
                          {project.demo && (
                            <Button variant="ghost" size="sm" asChild>
                              <Link href={project.demo} target="_blank" rel="noopener noreferrer">
                                <ExternalLink className="w-4 h-4" />
                              </Link>
                            </Button>
                          )}
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {project.technologies.slice(0, 3).map((tech) => (
                          <Badge key={tech} variant="outline" className="text-xs">
                            {tech}
                          </Badge>
                        ))}
                        {project.technologies.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{project.technologies.length - 3}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          {/* Call to Action */}
          <section className="mt-16 p-6 bg-muted/50 rounded-lg border border-border text-center">
            <h3 className="text-xl font-semibold text-foreground mb-4">¿Interesado en colaborar?</h3>
            <p className="text-muted-foreground mb-4">
              Si tienes ideas para proyectos de ciberseguridad o quieres contribuir a alguno existente, me encantaría
              escucharte.
            </p>
            <Button asChild>
              <Link href="/contact">Contactar</Link>
            </Button>
          </section>
        </div>
      </main>
    </div>
  )
}
