"use client"

import { useState, useMemo } from "react"
import type { BlogPost } from "@/lib/blog"

export interface SearchFilters {
  query: string
  category: string
  tags: string[]
}

export function useSearch(posts: BlogPost[], initialQuery?: string) {
  const [filters, setFilters] = useState<SearchFilters>({
    query: initialQuery || "",
    category: "Todos",
    tags: [],
  })

  const filteredPosts = useMemo(() => {
    return posts.filter((post) => {
      // Text search in title, description, and content
      const matchesQuery =
        filters.query === "" ||
        post.title.toLowerCase().includes(filters.query.toLowerCase()) ||
        post.description.toLowerCase().includes(filters.query.toLowerCase()) ||
        post.content.toLowerCase().includes(filters.query.toLowerCase()) ||
        post.tags.some((tag) => tag.toLowerCase().includes(filters.query.toLowerCase()))

      // Category filter
      const matchesCategory = filters.category === "Todos" || post.category === filters.category

      // Tags filter
      const matchesTags = filters.tags.length === 0 || filters.tags.some((filterTag) => post.tags.includes(filterTag))

      return matchesQuery && matchesCategory && matchesTags
    })
  }, [posts, filters])

  const updateQuery = (query: string) => {
    setFilters((prev) => ({ ...prev, query }))
  }

  const updateCategory = (category: string) => {
    setFilters((prev) => ({ ...prev, category }))
  }

  const toggleTag = (tag: string) => {
    setFilters((prev) => ({
      ...prev,
      tags: prev.tags.includes(tag) ? prev.tags.filter((t) => t !== tag) : [...prev.tags, tag],
    }))
  }

  const clearFilters = () => {
    setFilters({
      query: "",
      category: "Todos",
      tags: [],
    })
  }

  return {
    filters,
    filteredPosts,
    updateQuery,
    updateCategory,
    toggleTag,
    clearFilters,
    hasActiveFilters: filters.query !== "" || filters.category !== "Todos" || filters.tags.length > 0,
  }
}
