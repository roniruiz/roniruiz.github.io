"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { GlobalSearch } from "@/components/global-search"
import { Icons } from "@/components/icons"

const navigation = [
  { name: "Inicio", href: "/", icon: Icons.Home },
  { name: "Artículos", href: "/articles", icon: Icons.FileText },
  { name: "Recursos", href: "/resources", icon: Icons.Folder },
  { name: "Proyectos", href: "/projects", icon: Icons.Code },
  { name: "Sobre mí", href: "/about", icon: Icons.User },
  { name: "Contacto", href: "/contact", icon: Icons.Mail },
]

export function Navigation() {
  const pathname = usePathname()

  return (
    <nav className="fixed left-0 top-0 z-50 h-full w-64 bg-background border-r border-border">
      <div className="flex flex-col h-full">
        {/* Logo/Header */}
        <div className="p-6 border-b border-border">
          <Link href="/" className="flex items-center space-x-3">
            <div className="flex items-center justify-center w-10 h-10 bg-primary/10 rounded-lg border border-primary/20">
              <Icons.Shield className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-foreground">Ronny</h1>
              <p className="text-sm text-muted-foreground">Cybersecurity</p>
            </div>
          </Link>
        </div>

        {/* Global Search */}
        <div className="p-4 border-b border-border">
          <GlobalSearch />
        </div>

        {/* Navigation Links */}
        <div className="flex-1 px-4 py-6">
          <ul className="space-y-2">
            {navigation.map((item) => {
              const isActive = pathname === item.href
              return (
                <li key={item.name}>
                  <Link
                    href={item.href}
                    className={cn(
                      "flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
                      isActive
                        ? "bg-primary/10 text-primary border border-primary/20"
                        : "text-muted-foreground hover:text-foreground hover:bg-muted",
                    )}
                  >
                    <item.icon className="w-5 h-5" />
                    <span>{item.name}</span>
                  </Link>
                </li>
              )
            })}
          </ul>
        </div>

        {/* Terminal indicator */}
        <div className="p-4 border-t border-border">
          <div className="flex items-center space-x-2 text-xs text-muted-foreground">
            <Icons.Terminal className="w-4 h-4 text-primary" />
            <span className="font-mono">root@cybersec:~$</span>
          </div>
        </div>
      </div>
    </nav>
  )
}
