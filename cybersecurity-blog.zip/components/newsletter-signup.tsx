"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Mail, Shield, CheckCircle, AlertCircle } from "lucide-react"

interface NewsletterSignupProps {
  variant?: "default" | "compact" | "inline"
  title?: string
  description?: string
}

export function NewsletterSignup({
  variant = "default",
  title = "Mantente actualizado",
  description = "Recibe las últimas investigaciones y técnicas de ciberseguridad directamente en tu inbox.",
}: NewsletterSignupProps) {
  const [email, setEmail] = useState("")
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle")
  const [message, setMessage] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email) return

    setStatus("loading")

    try {
      // Buttondown API integration
      const response = await fetch("/api/newsletter/subscribe", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email }),
      })

      const data = await response.json()

      if (response.ok) {
        setStatus("success")
        setMessage("¡Suscripción exitosa! Revisa tu email para confirmar.")
        setEmail("")
      } else {
        setStatus("error")
        setMessage(data.error || "Error al suscribirse. Intenta nuevamente.")
      }
    } catch (error) {
      setStatus("error")
      setMessage("Error de conexión. Intenta nuevamente.")
    }

    // Reset status after 5 seconds
    setTimeout(() => {
      setStatus("idle")
      setMessage("")
    }, 5000)
  }

  if (variant === "compact") {
    return (
      <div className="bg-muted/50 p-4 rounded-lg border border-border">
        <div className="flex items-center space-x-2 mb-3">
          <Shield className="w-5 h-5 text-primary" />
          <h4 className="font-medium text-foreground">{title}</h4>
        </div>
        <form onSubmit={handleSubmit} className="flex space-x-2">
          <Input
            type="email"
            placeholder="tu@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            disabled={status === "loading"}
            className="flex-1"
          />
          <Button type="submit" disabled={status === "loading" || !email} size="sm">
            {status === "loading" ? "..." : "Suscribir"}
          </Button>
        </form>
        {message && (
          <div
            className={`flex items-center space-x-2 mt-2 text-sm ${
              status === "success" ? "text-green-600" : "text-red-600"
            }`}
          >
            {status === "success" ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
            <span>{message}</span>
          </div>
        )}
      </div>
    )
  }

  if (variant === "inline") {
    return (
      <div className="flex items-center space-x-4 p-4 bg-primary/5 border border-primary/20 rounded-lg">
        <div className="flex items-center space-x-2">
          <Mail className="w-5 h-5 text-primary" />
          <span className="font-medium text-foreground">Newsletter</span>
        </div>
        <form onSubmit={handleSubmit} className="flex space-x-2 flex-1">
          <Input
            type="email"
            placeholder="Suscríbete para más contenido"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            disabled={status === "loading"}
            className="flex-1"
          />
          <Button type="submit" disabled={status === "loading" || !email} size="sm">
            Suscribir
          </Button>
        </form>
        {message && (
          <div className={`text-sm ${status === "success" ? "text-green-600" : "text-red-600"}`}>{message}</div>
        )}
      </div>
    )
  }

  return (
    <Card className="bg-gradient-to-br from-primary/5 to-secondary/5 border-primary/20">
      <CardHeader className="text-center">
        <div className="flex items-center justify-center w-12 h-12 bg-primary/10 rounded-lg border border-primary/20 mx-auto mb-4">
          <Mail className="w-6 h-6 text-primary" />
        </div>
        <CardTitle className="flex items-center justify-center space-x-2">
          <span>{title}</span>
          <Badge variant="secondary" className="text-xs">
            Gratis
          </Badge>
        </CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex space-x-2">
            <Input
              type="email"
              placeholder="tu@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={status === "loading"}
              className="flex-1"
            />
            <Button type="submit" disabled={status === "loading" || !email}>
              {status === "loading" ? "Suscribiendo..." : "Suscribir"}
            </Button>
          </div>

          {message && (
            <div
              className={`flex items-center space-x-2 text-sm ${
                status === "success" ? "text-green-600" : "text-red-600"
              }`}
            >
              {status === "success" ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
              <span>{message}</span>
            </div>
          )}

          <div className="text-xs text-muted-foreground text-center">
            <p>• Contenido exclusivo sobre ciberseguridad</p>
            <p>• Sin spam, cancela cuando quieras</p>
            <p>• Máximo 1 email por semana</p>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
