import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock } from "lucide-react"
import Link from "next/link"
import type { BlogPost } from "@/lib/blog"

interface ArticleGridProps {
  posts: BlogPost[]
  showEmpty?: boolean
}

export function ArticleGrid({ posts, showEmpty = true }: ArticleGridProps) {
  if (posts.length === 0 && showEmpty) {
    return (
      <div className="text-center py-12">
        <h3 className="text-lg font-medium text-muted-foreground mb-2">No se encontraron artículos</h3>
        <p className="text-sm text-muted-foreground">
          Intenta ajustar los filtros de búsqueda o explora diferentes categorías.
        </p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {posts.map((post) => (
        <Card key={post.slug} className="group hover:border-primary/50 transition-colors">
          <CardHeader>
            <div className="flex items-center justify-between mb-2">
              <Badge variant="secondary" className="text-xs">
                {post.category}
              </Badge>
              <div className="flex items-center text-xs text-muted-foreground">
                <Calendar className="w-3 h-3 mr-1" />
                {new Date(post.date).toLocaleDateString("es-ES")}
              </div>
            </div>
            <CardTitle className="group-hover:text-primary transition-colors">
              <Link href={`/articles/${post.slug}`}>{post.title}</Link>
            </CardTitle>
            <CardDescription className="text-sm leading-relaxed">{post.excerpt}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="flex flex-wrap gap-1">
                {post.tags.slice(0, 2).map((tag) => (
                  <Badge key={tag} variant="outline" className="text-xs">
                    {tag}
                  </Badge>
                ))}
                {post.tags.length > 2 && (
                  <Badge variant="outline" className="text-xs">
                    +{post.tags.length - 2}
                  </Badge>
                )}
              </div>
              <div className="flex items-center text-xs text-muted-foreground">
                <Clock className="w-3 h-3 mr-1" />
                {post.readTime}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
