import { NewsletterSignup } from "@/components/newsletter-signup"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Github, Linkedin, Twitter, Mail, Shield } from "lucide-react"
import Link from "next/link"

const socialLinks = [
  {
    name: "GitHub",
    href: "https://github.com/ronny-cybersec",
    icon: Github,
  },
  {
    name: "LinkedIn",
    href: "https://linkedin.com/in/ronny-cybersec",
    icon: Linkedin,
  },
  {
    name: "Twitter",
    href: "https://twitter.com/ronny_cybersec",
    icon: Twitter,
  },
  {
    name: "Email",
    href: "mailto:ronny@cybersec.dev",
    icon: Mail,
  },
]

const footerLinks = [
  {
    title: "Contenido",
    links: [
      { name: "Artículos", href: "/articles" },
      { name: "Recursos", href: "/resources" },
      { name: "Proyectos", href: "/projects" },
    ],
  },
  {
    title: "Información",
    links: [
      { name: "Sobre mí", href: "/about" },
      { name: "Contacto", href: "/contact" },
    ],
  },
  {
    title: "Legal",
    links: [
      { name: "Términos de uso", href: "/terms" },
      { name: "Política de privacidad", href: "/privacy" },
    ],
  },
]

export function Footer() {
  return (
    <footer className="bg-background border-t border-border">
      <div className="max-w-6xl mx-auto px-8 py-12">
        {/* Newsletter Section */}
        <div className="mb-12">
          <NewsletterSignup variant="compact" />
        </div>

        <Separator className="mb-8" />

        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center space-x-3 mb-4">
              <div className="flex items-center justify-center w-10 h-10 bg-primary/10 rounded-lg border border-primary/20">
                <Shield className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-foreground">Ronny</h3>
                <p className="text-sm text-muted-foreground">Cybersecurity</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Compartiendo conocimiento sobre ciberseguridad, pentesting y seguridad de sistemas.
            </p>
            <div className="flex space-x-2">
              {socialLinks.map((link) => (
                <Button key={link.name} variant="ghost" size="sm" asChild>
                  <Link href={link.href} target="_blank" rel="noopener noreferrer">
                    <link.icon className="w-4 h-4" />
                  </Link>
                </Button>
              ))}
            </div>
          </div>

          {/* Links */}
          {footerLinks.map((section) => (
            <div key={section.title}>
              <h4 className="font-semibold text-foreground mb-4">{section.title}</h4>
              <ul className="space-y-2">
                {section.links.map((link) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <Separator className="my-8" />

        {/* Bottom Footer */}
        <div className="flex flex-col md:flex-row items-center justify-between text-sm text-muted-foreground">
          <p>© 2024 Ronny. Todos los derechos reservados.</p>
          <p className="mt-2 md:mt-0">Hecho con ❤️ para la comunidad de ciberseguridad</p>
        </div>
      </div>
    </footer>
  )
}
