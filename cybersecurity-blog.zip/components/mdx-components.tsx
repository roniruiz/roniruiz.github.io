import type React from "react"
import type { MDXComponents } from "mdx/types"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertTriangle, Info, CheckCircle, XCircle } from "lucide-react"

export const mdxComponents: MDXComponents = {
  // Custom heading components with better styling
  h1: ({ children }) => (
    <h1 className="text-3xl font-bold text-foreground mb-6 mt-8 border-b border-border pb-2">{children}</h1>
  ),
  h2: ({ children }) => <h2 className="text-2xl font-semibold text-foreground mb-4 mt-6">{children}</h2>,
  h3: ({ children }) => <h3 className="text-xl font-medium text-foreground mb-3 mt-4">{children}</h3>,

  // Enhanced paragraph styling
  p: ({ children }) => <p className="text-muted-foreground leading-relaxed mb-4">{children}</p>,

  // Code blocks with terminal styling
  pre: ({ children }) => (
    <div className="terminal-card p-4 rounded-lg my-6 overflow-x-auto">
      <pre className="font-mono text-sm text-foreground">{children}</pre>
    </div>
  ),

  // Inline code
  code: ({ children }) => <code className="bg-muted px-2 py-1 rounded text-sm font-mono text-primary">{children}</code>,

  // Enhanced blockquotes
  blockquote: ({ children }) => (
    <blockquote className="border-l-4 border-primary pl-4 py-2 my-4 bg-muted/50 rounded-r">
      <div className="text-muted-foreground italic">{children}</div>
    </blockquote>
  ),

  // Lists with better spacing
  ul: ({ children }) => <ul className="list-disc list-inside space-y-2 mb-4 text-muted-foreground">{children}</ul>,
  ol: ({ children }) => <ol className="list-decimal list-inside space-y-2 mb-4 text-muted-foreground">{children}</ol>,

  // Custom components for cybersecurity content
  SecurityAlert: ({
    type = "info",
    title,
    children,
  }: {
    type?: "info" | "warning" | "success" | "error"
    title?: string
    children: React.ReactNode
  }) => {
    const icons = {
      info: Info,
      warning: AlertTriangle,
      success: CheckCircle,
      error: XCircle,
    }
    const Icon = icons[type]

    return (
      <Alert className="my-4">
        <Icon className="h-4 w-4" />
        {title && <AlertTitle>{title}</AlertTitle>}
        <AlertDescription>{children}</AlertDescription>
      </Alert>
    )
  },

  CommandBlock: ({ children }: { children: React.ReactNode }) => (
    <div className="terminal-card p-4 rounded-lg my-4">
      <div className="flex items-center space-x-2 mb-2">
        <div className="w-3 h-3 rounded-full bg-red-500"></div>
        <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
        <div className="w-3 h-3 rounded-full bg-green-500"></div>
        <span className="text-xs text-muted-foreground ml-2">Terminal</span>
      </div>
      <div className="font-mono text-sm">
        <span className="text-primary">root@kali:~$ </span>
        <span className="text-secondary">{children}</span>
      </div>
    </div>
  ),

  ToolCard: ({
    name,
    description,
    category,
  }: {
    name: string
    description: string
    category: string
  }) => (
    <Card className="my-4">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">{name}</CardTitle>
          <Badge variant="secondary">{category}</Badge>
        </div>
      </CardHeader>
      <CardContent>
        <CardDescription>{description}</CardDescription>
      </CardContent>
    </Card>
  ),
}
