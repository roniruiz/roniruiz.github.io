"use client"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Search, Filter, X, Hash, Folder } from "lucide-react"
import type { SearchFilters } from "@/hooks/use-search"

interface SearchFiltersProps {
  filters: SearchFilters
  categories: string[]
  tags: string[]
  onQueryChange: (query: string) => void
  onCategoryChange: (category: string) => void
  onTagToggle: (tag: string) => void
  onClearFilters: () => void
  hasActiveFilters: boolean
  resultsCount: number
}

function SearchFiltersComponent({
  filters,
  categories,
  tags,
  onQueryChange,
  onCategoryChange,
  onTagToggle,
  onClearFilters,
  hasActiveFilters,
  resultsCount,
}: SearchFiltersProps) {
  return (
    <div className="space-y-6">
      {/* Search Input */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Buscar artículos, tecnologías, conceptos..."
          className="pl-10 pr-4"
          value={filters.query}
          onChange={(e) => onQueryChange(e.target.value)}
        />
      </div>

      {/* Results Count and Clear Filters */}
      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">
          {resultsCount} {resultsCount === 1 ? "artículo encontrado" : "artículos encontrados"}
        </div>
        {hasActiveFilters && (
          <Button variant="ghost" size="sm" onClick={onClearFilters}>
            <X className="w-4 h-4 mr-2" />
            Limpiar filtros
          </Button>
        )}
      </div>

      {/* Categories Filter */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center space-x-2">
            <Folder className="w-4 h-4 text-primary" />
            <span>Categorías</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="flex flex-wrap gap-2">
            {["Todos", ...categories].map((category) => (
              <Badge
                key={category}
                variant={filters.category === category ? "default" : "outline"}
                className="cursor-pointer hover:bg-primary/10 transition-colors"
                onClick={() => onCategoryChange(category)}
              >
                {category}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Tags Filter */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center space-x-2">
            <Hash className="w-4 h-4 text-primary" />
            <span>Etiquetas</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="flex flex-wrap gap-2">
            {tags.map((tag) => (
              <Badge
                key={tag}
                variant={filters.tags.includes(tag) ? "default" : "outline"}
                className="cursor-pointer hover:bg-primary/10 transition-colors"
                onClick={() => onTagToggle(tag)}
              >
                {tag}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Active Filters Summary */}
      {hasActiveFilters && (
        <Card className="bg-muted/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center space-x-2">
              <Filter className="w-4 h-4 text-primary" />
              <span>Filtros activos</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-2">
            {filters.query && (
              <div className="flex items-center space-x-2">
                <span className="text-xs text-muted-foreground">Búsqueda:</span>
                <Badge variant="secondary" className="text-xs">
                  "{filters.query}"
                </Badge>
              </div>
            )}
            {filters.category !== "Todos" && (
              <div className="flex items-center space-x-2">
                <span className="text-xs text-muted-foreground">Categoría:</span>
                <Badge variant="secondary" className="text-xs">
                  {filters.category}
                </Badge>
              </div>
            )}
            {filters.tags.length > 0 && (
              <div className="flex items-center space-x-2">
                <span className="text-xs text-muted-foreground">Etiquetas:</span>
                <div className="flex flex-wrap gap-1">
                  {filters.tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}

export { SearchFiltersComponent as SearchFilters }
