"use client"

import { useState, useEffect } from "react"
import { Icons } from "@/components/icons"

const commands = [
  "whoami",
  "Ronny - Systems Engineer",
  "cat /etc/specialization",
  "Cybersecurity & Penetration Testing",
  "ls -la /skills/",
  "Network Security, Ethical Hacking, System Hardening",
  'echo "Welcome to my digital fortress"',
  "Welcome to my digital fortress",
]

export function TerminalHero() {
  const [displayedCommands, setDisplayedCommands] = useState<string[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)

  useEffect(() => {
    if (currentIndex < commands.length) {
      const timer = setTimeout(() => {
        setDisplayedCommands((prev) => [...prev, commands[currentIndex]])
        setCurrentIndex((prev) => prev + 1)
      }, 800)
      return () => clearTimeout(timer)
    }
  }, [currentIndex])

  return (
    <div className="terminal-card p-6 rounded-lg max-w-2xl">
      <div className="flex items-center space-x-2 mb-4">
        <Icons.Terminal className="w-5 h-5 text-primary" />
        <span className="text-sm font-mono text-muted-foreground">terminal</span>
        <div className="flex space-x-1 ml-auto">
          <div className="w-3 h-3 rounded-full bg-red-500"></div>
          <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
          <div className="w-3 h-3 rounded-full bg-green-500"></div>
        </div>
      </div>

      <div className="font-mono text-sm space-y-2">
        {displayedCommands.map((command, index) => (
          <div key={index} className={index % 2 === 0 ? "text-secondary" : "terminal-text"}>
            {index % 2 === 0 && <span className="text-primary">root@cybersec:~$ </span>}
            {command}
          </div>
        ))}
        {currentIndex < commands.length && (
          <div className="text-secondary">
            <span className="text-primary">root@cybersec:~$ </span>
            <span className="animate-pulse">_</span>
          </div>
        )}
      </div>
    </div>
  )
}
