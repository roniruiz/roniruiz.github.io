"use client"

import { useState } from "react"
import { SearchFilters } from "@/components/search-filters"
import { ArticleGrid } from "@/components/article-grid"
import { useSearch } from "@/hooks/use-search"
import { Button } from "@/components/ui/button"
import { Icons } from "@/components/icons"
import type { BlogPost } from "@/lib/blog"

interface ArticlesClientProps {
  posts: BlogPost[]
  categories: string[]
  tags: string[]
}

export function ArticlesClient({ posts, categories, tags }: ArticlesClientProps) {
  const [showFilters, setShowFilters] = useState(true)

  const { filters, filteredPosts, updateQuery, updateCategory, toggleTag, clearFilters, hasActiveFilters } =
    useSearch(posts)

  return (
    <main className="ml-64 p-8">
      <div className="max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-4">Artículos Técnicos</h1>
              <p className="text-muted-foreground text-lg">
                Explora mis investigaciones y experiencias en ciberseguridad, pentesting y seguridad de sistemas.
              </p>
            </div>
            <Button variant="outline" size="sm" onClick={() => setShowFilters(!showFilters)} className="lg:hidden">
              {showFilters ? (
                <>
                  <Icons.SidebarClose className="w-4 h-4 mr-2" />
                  Ocultar filtros
                </>
              ) : (
                <>
                  <Icons.SidebarOpen className="w-4 h-4 mr-2" />
                  Mostrar filtros
                </>
              )}
            </Button>
          </div>
        </div>

        <div className="flex gap-8">
          {/* Filters Sidebar */}
          <aside className={`w-80 flex-shrink-0 ${showFilters ? "block" : "hidden lg:block"}`}>
            <div className="sticky top-8">
              <SearchFilters
                filters={filters}
                categories={categories}
                tags={tags}
                onQueryChange={updateQuery}
                onCategoryChange={updateCategory}
                onTagToggle={toggleTag}
                onClearFilters={clearFilters}
                hasActiveFilters={hasActiveFilters}
                resultsCount={filteredPosts.length}
              />
            </div>
          </aside>

          {/* Articles Grid */}
          <div className="flex-1 min-w-0">
            <ArticleGrid posts={filteredPosts} />
          </div>
        </div>
      </div>
    </main>
  )
}
