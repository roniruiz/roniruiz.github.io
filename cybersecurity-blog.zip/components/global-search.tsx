"use client"

import { useState, useEffect, useRef } from "react"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Search, FileText, Calendar } from "lucide-react"
import Link from "next/link"
import type { BlogPost } from "@/lib/blog"

export function GlobalSearch() {
  const [query, setQuery] = useState("")
  const [results, setResults] = useState<BlogPost[]>([])
  const [isOpen, setIsOpen] = useState(false)
  const [allPosts, setAllPosts] = useState<BlogPost[]>([])
  const searchRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    async function fetchPosts() {
      try {
        const response = await fetch("/api/posts")
        if (response.ok) {
          const posts = await response.json()
          setAllPosts(posts)
        }
      } catch (error) {
        console.error("[v0] Error fetching posts:", error)
      }
    }
    fetchPosts()
  }, [])

  useEffect(() => {
    if (query.length < 2) {
      setResults([])
      setIsOpen(false)
      return
    }

    const filtered = allPosts
      .filter((post) => {
        const searchTerm = query.toLowerCase()
        return (
          post.title.toLowerCase().includes(searchTerm) ||
          post.description.toLowerCase().includes(searchTerm) ||
          post.tags.some((tag) => tag.toLowerCase().includes(searchTerm)) ||
          post.category.toLowerCase().includes(searchTerm)
        )
      })
      .slice(0, 5) // Limit to 5 results

    setResults(filtered)
    setIsOpen(filtered.length > 0)
  }, [query, allPosts])

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  return (
    <div ref={searchRef} className="relative">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Buscar en el blog..."
          className="pl-10 pr-4 w-64"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => query.length >= 2 && results.length > 0 && setIsOpen(true)}
        />
      </div>

      {isOpen && (
        <Card className="absolute top-full left-0 right-0 mt-2 z-50 max-h-96 overflow-y-auto">
          <CardContent className="p-0">
            {results.map((post) => (
              <Link
                key={post.slug}
                href={`/articles/${post.slug}`}
                className="block p-4 hover:bg-muted/50 transition-colors border-b border-border last:border-b-0"
                onClick={() => {
                  setIsOpen(false)
                  setQuery("")
                }}
              >
                <div className="flex items-start space-x-3">
                  <FileText className="w-4 h-4 text-primary mt-1 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-foreground text-sm line-clamp-1">{post.title}</h4>
                    <p className="text-xs text-muted-foreground line-clamp-2 mt-1">{post.description}</p>
                    <div className="flex items-center space-x-2 mt-2">
                      <Badge variant="outline" className="text-xs">
                        {post.category}
                      </Badge>
                      <div className="flex items-center text-xs text-muted-foreground">
                        <Calendar className="w-3 h-3 mr-1" />
                        {new Date(post.date).toLocaleDateString("es-ES")}
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
            {query.length >= 2 && results.length === 0 && (
              <div className="p-4 text-center text-sm text-muted-foreground">
                No se encontraron resultados para "{query}"
              </div>
            )}
            {results.length > 0 && (
              <div className="p-3 border-t border-border">
                <Link
                  href={`/articles?q=${encodeURIComponent(query)}`}
                  className="text-xs text-primary hover:underline"
                  onClick={() => {
                    setIsOpen(false)
                    setQuery("")
                  }}
                >
                  Ver todos los resultados →
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
