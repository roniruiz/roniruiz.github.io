export function StructuredData() {
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "Blog",
    name: "RONNY | Sistemas & Ciberseguridad",
    description: "Tutoriales, guías y proyectos de ciberseguridad con enfoque educativo y ético",
    url: "https://ronny-cybersec.vercel.app",
    author: {
      "@type": "Person",
      name: "Ronny",
      jobTitle: "Ingeniero en Sistemas",
      knowsAbout: ["Ciberseguridad", "Pentesting", "Seguridad de Redes", "Kali Linux"],
    },
    publisher: {
      "@type": "Person",
      name: "Ronny",
    },
    inLanguage: "es-ES",
    blogPost: [
      {
        "@type": "BlogPosting",
        headline: "Kali Linux: mi setup rápido para pentesting",
        url: "https://ronny-cybersec.vercel.app/articles/kali-setup-rapido",
        datePublished: "2024-01-15",
        author: {
          "@type": "Person",
          name: "Ronny",
        },
      },
      {
        "@type": "BlogPosting",
        headline: "Nmap práctico: 12 comandos que uso diario",
        url: "https://ronny-cybersec.vercel.app/articles/nmap-12-comandos",
        datePublished: "2024-01-10",
        author: {
          "@type": "Person",
          name: "Ronny",
        },
      },
      {
        "@type": "BlogPosting",
        headline: "WiFi segura en casa: guía directa",
        url: "https://ronny-cybersec.vercel.app/articles/wifi-segura-casa",
        datePublished: "2024-01-05",
        author: {
          "@type": "Person",
          name: "Ronny",
        },
      },
    ],
  }

  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }} />
}
