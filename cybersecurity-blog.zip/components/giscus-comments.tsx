"use client"

import { useEffect, useRef } from "react"
import { useTheme } from "next-themes"

interface GiscusCommentsProps {
  slug: string
}

export function GiscusComments({ slug }: GiscusCommentsProps) {
  const ref = useRef<HTMLDivElement>(null)
  const { theme } = useTheme()

  useEffect(() => {
    if (!ref.current || ref.current.hasChildNodes()) return

    const scriptElem = document.createElement("script")
    scriptElem.src = "https://giscus.app/client.js"
    scriptElem.async = true
    scriptElem.crossOrigin = "anonymous"

    // Giscus configuration
    scriptElem.setAttribute("data-repo", "ronny-cybersec/blog-comments") // Replace with actual repo
    scriptElem.setAttribute("data-repo-id", "R_kgDOK8") // Replace with actual repo ID
    scriptElem.setAttribute("data-category", "General")
    scriptElem.setAttribute("data-category-id", "DIC_kwDOK8") // Replace with actual category ID
    scriptElem.setAttribute("data-mapping", "pathname")
    scriptElem.setAttribute("data-strict", "0")
    scriptElem.setAttribute("data-reactions-enabled", "1")
    scriptElem.setAttribute("data-emit-metadata", "0")
    scriptElem.setAttribute("data-input-position", "top")
    scriptElem.setAttribute("data-theme", theme === "dark" ? "dark" : "light")
    scriptElem.setAttribute("data-lang", "es")
    scriptElem.setAttribute("data-loading", "lazy")

    ref.current.appendChild(scriptElem)
  }, [slug, theme])

  // Remove script when component unmounts
  useEffect(() => {
    return () => {
      if (ref.current) {
        ref.current.innerHTML = ""
      }
    }
  }, [])

  return (
    <section className="mt-12">
      <div className="border-t border-border pt-8">
        <h3 className="text-xl font-semibold text-foreground mb-6">Comentarios</h3>
        <div ref={ref} />
      </div>
    </section>
  )
}
